#!/usr/bin/env python3


from brain_games.logic_even import logic


def even():
    print('Welcome to the Brain Games!')
    logic()

if __name__ == '__even__':
    even()