import random
import prompt


def logic(question, correct_answer):
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print(question)
    print(correct_answer)
#    i = 0
 #   while i < 3:
  #      answer = prompt.string('Your answer: ')
   #        print('Correct!')
    #    else:
     #       print(f'"{answer}" is wrong answer ;(. Correct answer was "{correct_answer}"')
      #      print(f"Let's try again, {name}!")
       #     break
        #i += 1
    #if i == 3:
     #   print(f"'Congratulations, {name}!'")
   # return