# import random
#
# def even():
#     question = 'Answer "yes" if the number is even, otherwise answer "no".'
#     number1 = random.randint(1, 100)
#     number2 = random.randint(1, 100)
#     action = random.sample(['+', '-', '*'], 1)
#     correct_answer = eval(number1 + action + number2)
#
#
#         if answer == correct_answer:
#             print('Correct!')
#         else:
#             print(f'"{answer}" is wrong answer ;(. Correct answer was "{correct_answer}"')
#             print(f"Let's try again, {name}!")
#             break
#         i += 1
#     if i == 3:
#         print(f"'Congratulations, {name}!'")
#     return
